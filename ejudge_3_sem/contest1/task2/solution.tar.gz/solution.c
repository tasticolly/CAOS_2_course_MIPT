#include <stdio.h>
int main() {
printf("%s","some_string_value\nsome another value with spaces\n");
printf("%d",12);}
